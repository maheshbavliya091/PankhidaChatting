package com.pankhida.chatting

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*

object OnlineStatusManager {
    private lateinit var database: FirebaseDatabase
    private lateinit var auth: FirebaseAuth

    fun initialize() {
        database = FirebaseDatabase.getInstance()
        auth = FirebaseAuth.getInstance()
    }

    fun setOnlineStatus(isOnline: Boolean) {
        val uid = auth.currentUser?.uid ?: return
        val userRef = database.reference.child("users").child(uid)

        val updates = HashMap<String, Any>()
        updates["onlineStatus"] = isOnline
        if (!isOnline) {
            updates["lastSeen"] = System.currentTimeMillis()
        }

        userRef.updateChildren(updates)
    }

    fun setupPresenceSystem() {
        val uid = auth.currentUser?.uid ?: return
        val userRef = database.reference.child("users").child(uid)

        val connectedRef = database.getReference(".info/connected")
        connectedRef.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val connected = snapshot.getValue(Boolean::class.java) ?: false
                if (connected) {