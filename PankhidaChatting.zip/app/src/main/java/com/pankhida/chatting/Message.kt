package com.pankhida.chatting

data class Message(
    val message: String = "",
    val senderId: String = "",
    val timestamp: Long = 0,
    val type: String = "text",
    val imageUrl: String = ""
)