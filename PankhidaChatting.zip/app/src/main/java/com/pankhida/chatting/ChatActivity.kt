package com.pankhida.chatting

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*
import com.google.firebase.storage.FirebaseStorage
import com.pankhida.chatting.databinding.ActivityChatBinding

class ChatActivity : AppCompatActivity() {
    private lateinit var binding: ActivityChatBinding
    private lateinit var messageAdapter: MessageAdapter
    private lateinit var messages: ArrayList<Message>
    private lateinit var database: DatabaseReference
    private lateinit var storage: FirebaseStorage
    private lateinit var notificationManager: NotificationManager

    private var receiverRoom: String? = null
    private var senderRoom: String? = null
    private var receiverId: String? = null
    private var receiverName: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityChatBinding.inflate(layoutInflater)
        setContentView(binding.root)

        receiverId = intent.getStringExtra("userId")
        receiverName = intent.getStringExtra("userName")
        val senderUid = FirebaseAuth.getInstance().currentUser?.uid

        database = FirebaseDatabase.getInstance().reference
        storage = FirebaseStorage.getInstance()
        notificationManager = NotificationManager(this)

        senderRoom = receiverId + senderUid
        receiverRoom = senderUid + receiverId

        setupUI()
        setupMessageSending()
        setupFileSharing()
        observeOnlineStatus()
    }

    private fun setupUI() {
        messages = ArrayList()
        messageAdapter = MessageAdapter(this, messages)
        binding.chatRecyclerView.layoutManager = LinearLayoutManager(this)
        binding.chatRecyclerView.adapter = messageAdapter

        database.child("chats").child(senderRoom!!).child("messages")
            .addValueEventListener(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    messages.clear()
                    for (messageSnapshot in snapshot.children) {
                        val message = messageSnapshot.getValue(Message::class.java)
                        messages.add(message!!)
                    }
                    messageAdapter.notifyDataSetChanged()
                    binding.chatRecyclerView.scrollToPosition(messages.size - 1)
                }

                override fun onCancelled(error: DatabaseError) {}
            })
    }

    private fun setupMessageSending() {
        binding.sendButton.setOnClickListener {
            val messageText = binding.messageBox.text.toString()
            if (messageText.isNotEmpty()) {
                sendMessage(messageText, "text")
            }
        }
    }

    private fun setupFileSharing() {
        binding.attachButton.setOnClickListener {
            val intent = Intent()
            intent.type = "image/*"
            intent.action = Intent.ACTION_GET_CONTENT
            startActivityForResult(intent, 1)
        }
    }

    private fun sendMessage(content: String, type: String, imageUrl: String = "") {
        val message = Message(
            content,
            FirebaseAuth.getInstance().currentUser?.uid!!,
            System.currentTimeMillis(),
            type,
            imageUrl
        )

        database.child("chats").child(senderRoom!!).child("messages").push()
            .setValue(message).addOnSuccessListener {
                database.child("chats").child(receiverRoom!!).child("messages").push()
                    .setValue(message)

                notificationManager.sendNotification(
                    receiverId!!,
                    if (type == "text") content else "Sent an image",
                    FirebaseAuth.getInstance().currentUser?.displayName ?: "User"
                )
            }

        binding.messageBox.setText("")
    }

    private fun observeOnlineStatus() {
        receiverId?.let { uid ->
            database.child("users").child(uid)
                .addValueEventListener(object : ValueEventListener {
                    override fun onDataChange(snapshot: DataSnapshot) {
                        val user = snapshot.getValue(User::class.java)
                        val status = if (user?.onlineStatus == true) {
                            "Online"
                        } else {
                            "Last seen: ${getTimeAgo(user?.lastSeen ?: 0)}"
                        }
                        binding.userStatus.text = status
                    }

                    override fun onCancelled(error: DatabaseError) {}
                })
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1 && resultCode == Activity.RESULT_OK && data?.data != null) {
            val imageUri: Uri = data.data!!
            val reference = storage.reference.child("Chat_Images")
                .child(System.currentTimeMillis().toString())

            binding.progressBar.visibility = View.VISIBLE

            reference.putFile(imageUri).addOnCompleteListener { task ->
                binding.progressBar.visibility = View.GONE
                if (task.isSuccessful) {
                    reference.downloadUrl.addOnSuccessListener { uri ->
                        sendMessage(uri.toString(), "image", uri.toString())
                    }
                }
            }
        }
    }

    private fun getTimeAgo(time: Long): String {
        val diff = System.currentTimeMillis() - time
        return when {
            diff < 60000 -> "just now"
            diff < 3600000 -> "${diff / 60000} minutes ago"
            diff < 86400000 -> "${diff / 3600000} hours ago"
            else -> "${diff / 86400000} days ago"
        }
    }
}