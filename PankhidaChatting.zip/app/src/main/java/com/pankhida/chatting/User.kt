package com.pankhida.chatting

data class User(
    val uid: String = "",
    val name: String = "",
    val email: String = "",
    val profileImage: String = "",
    val status: String = "",
    val onlineStatus: Boolean = false,
    val lastSeen: Long = 0
)