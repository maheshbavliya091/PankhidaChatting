package com.pankhida.chatting

import android.content.Context
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.messaging.FirebaseMessaging
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.IOException

class NotificationManager(private val context: Context) {
    private val fcm = FirebaseMessaging.getInstance()
    private val database = FirebaseDatabase.getInstance()

    fun updateToken() {
        fcm.token.addOnCompleteListener { task ->
            if (task.isSuccessful) {
                val token = task.result
                val uid = FirebaseAuth.getInstance().currentUser?.uid
                if (uid != null) {
                    database.reference.child("users").child(uid)
                        .child("fcmToken").setValue(token)
                }
            }
        }
    }

    fun sendNotification(receiverId: String, message: String, senderName: String) {
        database.reference.child("users").child(receiverId)
            .child("fcmToken").get().addOnSuccessListener { snapshot ->
                val token = snapshot.getValue(String::class.java)
                if (token != null) {
                    val notification = JSONObject().apply {
                        put("to", token)